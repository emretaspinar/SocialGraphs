Film collaboration network (2026-11-09)
Plot section of the English Wikipedia article for each film in films_nodes.tsv.
One file per film. The filename is the node_id, URL-encoded, because some titles
contain characters a filesystem will not take (Mad_Max:_Fury_Road).
urllib.parse.unquote the stem and it matches node_id exactly.
